package healthcenter;

import healthcenter.config.kafka.KafkaProcessor;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

@Service
public class PolicyHandler{
    @Autowired ProductRepository productRepository;

//구문 추가
    @StreamListener(KafkaProcessor.INPUT)
    public void onStringEventListener(@Payload String eventString){

    }

   @StreamListener(KafkaProcessor.INPUT)
   public void wheneverReserveAccepted_(@Payload ReserveAccepted reserveAccepted){

//구문 추가
    if(reserveAccepted.isMe()){
        System.out.println("##### listener  : " + reserveAccepted.toJson());
        Product product = new Product();
        product.setStatus("Reservation Complete!");
        product.setOrderId(reserveAccepted.getOrderId());
        product.setReservationId(reserveAccepted.getId());
        productRepository.save(product);
  }
    }

//주석 처리
//    @StreamListener(KafkaProcessor.INPUT)
//    public void whatever(@Payload String eventString){}


}
